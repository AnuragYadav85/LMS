import pandas as pd
import sqlite3
import time
import smtplib
import random


from datetime import datetime, date, timedelta
from io import StringIO
from flask import Flask, render_template, request, redirect, session, Response, jsonify

sql = sqlite3.connect("data.db", check_same_thread=False)
cursor = sql.cursor()


cursor.execute("PRAGMA foreign_keys = ON;")

cursor.execute("""
CREATE TABLE IF NOT EXISTS employee (
    email TEXT NOT NULL,
    name TEXT NOT NULL,
    surname TEXT NOT NULL,
    department TEXT NOT NULL,
    password TEXT NOT NULL,
    join_date TEXT NOT NULL,
    PRIMARY KEY (email)
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS admin_table (
    email TEXT NOT NULL,
    name TEXT NOT NULL,
    surname TEXT NOT NULL,
    department TEXT NOT NULL,
    password TEXT NOT NULL,
    join_date TEXT NOT NULL,
    PRIMARY KEY (email)
)
""")


cursor.execute("""
CREATE TABLE IF NOT EXISTS leave_record (
    email TEXT NOT NULL,
    leave_date_start TEXT NOT NULL,
    leave_date_end TEXT NOT NULL,
    leave_type TEXT CHECK(leave_type IN ('SL', 'CL', 'COFF','SV','PL','LWP','DL','EL')) NOT NULL,
    applyed_on TEXT DEFAULT (DATE('now')),
    PRIMARY KEY (email, leave_date_start, leave_date_end)
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS leave_remaining (
    email TEXT NOT NULL,
    SL FLOAT DEFAULT 0,
    CL FLOAT DEFAULT 0,
    COFF FLOAT DEFAULT 0,
    SV FLOAT DEFAULT 0,
    PL FLOAT DEFAULT 0,
    DL INTEGER DEFAULT 0,
    EL FLOAT DEFAULT 0
)
""")


cursor.execute("""
CREATE TABLE IF NOT EXISTS approve_table (
    email TEXT NOT NULL,
    leave_type TEXT CHECK(leave_type IN ('SL', 'CL', 'COFF','SV','PL','LWP','DL','EL')) NOT NULL,
    leave_date_start TEXT NOT NULL,
    leave_date_end TEXT NOT NULL,
    applyed_on TEXT DEFAULT (DATE('now')),
    approve TEXT NOT NULL DEFAULT 'Pending'
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS system_config (
    key TEXT PRIMARY KEY,
    value TEXT
)
""")

cursor.execute("""CREATE TABLE IF NOT EXISTS admin_email (email)""")

cursor.execute("""CREATE TABLE IF NOT EXISTS sms_table (email TEXT PRIMARY KEY, sms TEXT, timestamp DATETIME)""")

cursor.execute("""
INSERT OR IGNORE INTO system_config (key, value)
VALUES ('last_leave_update', ?)
""",((date.today().isoformat(),)))

sql.commit()


def auto_add_leave():
    today = date.today()
    today_str = today.isoformat()

    last_update_str = cursor.execute("SELECT value FROM system_config WHERE key='last_leave_update'").fetchone()[0]
    last_update = date.fromisoformat(last_update_str)

    if today.month != last_update.month or today.year != last_update.year:
        cursor.execute("""
            UPDATE leave_remaining
            SET SL = SL + 0.83,
                CL = CL + 1
        """)

        cursor.execute("""
            UPDATE system_config
            SET value = ?
            WHERE key = 'last_leave_update'
        """, (today_str,))

        sql.commit()


def outer_add_emp(email, name, surname, department, password, type, join_date):
    email = email.lower()

    if email != f"{name.lower()}.{surname.lower()}@gnims.com":
        return "Invalid email format OR name/surname does not match!"

    if type == 'admin':
        cursor.execute("SELECT email FROM admin_table WHERE email = ?", (email,))
        if cursor.fetchone():
            return f"Admin {email} already exists!"

        cursor.execute("""
            INSERT INTO admin_table
            (email, name, surname, department, password, join_date)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (email, name, surname, department, password, join_date))

        cursor.execute(
            "INSERT INTO leave_remaining (email) VALUES (?)",
            (email,)
        )
                
        cursor.execute("""INSERT OR IGNORE INTO admin_email (email) VALUES (?)
                       """, (email,))
        
        sql.commit()
        return f"Admin {email} added successfully!"
    else:
        cursor.execute("SELECT email FROM employee WHERE email = ?", (email,))
        if cursor.fetchone():
            return f"Employee {email} already exists!"

        cursor.execute("""
            INSERT INTO employee
            (email, name, surname, department, password, join_date)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (email, name, surname, department, password, join_date))

        cursor.execute(
            "INSERT INTO leave_remaining (email) VALUES (?)",
            (email,)
        )

        sql.commit()
        return f"Employee {email} added successfully!"
outer_add_emp("anurag.yadav@gnims.com", "Anurag", "Yadav", "IT", "123", "admin", "2025-06-25")

def date_count(email, start, end , leave_type):
    start_date = datetime.strptime(start, "%Y-%m-%d")
    end_date = datetime.strptime(end, "%Y-%m-%d")
    count = (end_date - start_date).days + 1
    cursor.execute(f"""
        UPDATE leave_remaining
        SET {leave_type} = {leave_type} - ?
        WHERE email = ?
    """, (count, email,))

def update_last_activity():
    session['last_activity'] = time.time()

def send_email_admin(subject, body):
    to_address = cursor.execute("SELECT email FROM admin_email").fetchone()
    mail = smtplib.SMTP('smtp.gmail.com', 587)
    mail.starttls()
    mail.login('anuragyadav8591@gmail.com', 'alaiiqrmnupjzmlt')
    message = f"Subject: {subject}\n\n{body}"
    mail.sendmail('anuragyadav8591@gmail.com', to_address, message)
    mail.quit()

def send_email_emp(subject, body, email):
    mail = smtplib.SMTP('smtp.gmail.com', 587)
    mail.starttls()
    mail.login('anuragyadav8591@gmail.com', 'alaiiqrmnupjzmlt')
    message = f"Subject: {subject}\n\n{body}"
    mail.sendmail('anuragyadav8591@gmail.com', email, message)
    mail.quit()
    

app = Flask(__name__)
app.secret_key = "your_secret_key"


@app.route("/")
def home():
    return render_template("login.html")

@app.route("/login_page")
def login_page():
    return render_template("login.html")

@app.route("/admin_login_page")
def admin_login_page():
    return render_template("admin_login.html")

@app.route("/dashboard_page")
def dashboard_page():
    if "type" not in session:
        return redirect("/")
    if session.get("type") == "admin":
        return render_template("admin_dashboard.html")
    cursor.execute("""
      SELECT SL, CL, COFF, SV 
      FROM leave_remaining 
      WHERE email = ?
    """, (session.get("email"),))

    balance = cursor.fetchone()

    return render_template("employee_dashboard.html", balance=balance)


@app.route("/leavehistory_page")
def leavehistory_page():
    email = session.get("email")
    cursor.execute("""
        SELECT leave_type, leave_date_start, leave_date_end, approve
        FROM approve_table
        WHERE email = ?
        ORDER BY leave_date_start DESC
    """, (email,))
    data = cursor.fetchall()
    return render_template("leave_history.html", data=data)


@app.route("/applyleave_page")
def applyleave_page():
    if "email" not in session:
        return redirect("/")
    return render_template("apply_leave.html")


@app.route("/add_employee_page")
def add_employee_page():
    return render_template("add_employee.html")

@app.route("/approve_leave_page")
def approve_leave_page():
    if "email" not in session:
        return redirect("/")
    cursor.execute("SELECT * FROM approve_table")
    rows = cursor.fetchall()
    return render_template("approve_leave.html", data=rows)

@app.route("/add_leave_balance_page")
def add_leave_balance_page():
    cursor.execute("SELECT email, name, surname FROM employee")
    employees = cursor.fetchall()
    return render_template("add_leave_balance.html", employees=employees)

@app.route("/download_all_reports_page")
def download_all_reports_page():
    return render_template("download_all_reports.html")

@app.route("/forgot_password_page")
def forgot_password_page():
    email = request.args.get("email")
    type = request.args.get("type")
    step = request.args.get("step")
    data = request.args.get("data")

    return render_template(
        "forgot_password.html",
        email=email,
        type=type,
        step=step,
        data=data
    )


@app.before_request
def run_monthly_leave():
    auto_add_leave()


@app.route("/login", methods=["POST"])
def login():
    email = request.form["email"].lower()
    password = request.form["password"]

    cursor.execute("""
        SELECT email, name, surname, department, join_date
        FROM employee WHERE EMAIL = ? AND PASSWORD = ?
    """, (email, password))

    data = cursor.fetchone()
    sql.commit()

    if data is None:
        return "Invalid Email or Password Credential"

    session["type"] = "employee"
    session["email"] = email
    session["user_name"] = data[1]
    session["surname"] = data[2]
    session["department"] = data[3]
    session["join_date"] = data[4]
    update_last_activity()

    return redirect("/dashboard_page")


@app.route("/admin_login", methods=["POST"])
def admin_login():
    email = request.form["email"].lower()
    password = request.form["password"]

    cursor.execute("""
        SELECT email, name, surname, department, join_date
        FROM admin_table WHERE EMAIL = ? AND PASSWORD = ?
    """, (email, password))

    data = cursor.fetchone()
    sql.commit()

    if data is None:
        return "Invalid Email or Password Credential"

    session["type"] = "admin"
    session["email"] = email
    session["user_name"] = data[1]
    session["surname"] = data[2]
    session["department"] = data[3]
    session["join_date"] = data[4]
    update_last_activity()

    return redirect("/dashboard_page")


@app.route("/forgot_password", methods=["POST"])
def forgot_password():
    email = request.form["email"]
    sms = request.form["sms"]
    new_password = request.form["new_password"]
    confirm_password = request.form["confirm_password"]
    type = request.form["type"]

    if new_password != confirm_password:
        return "New Password and Confirm Password do not match"

    cursor.execute("SELECT sms FROM sms_table WHERE email = ?", (email,))
    sms_record = cursor.fetchone()
    
    if sms_record == None:
        return render_template("/forgot_password.html", data="Email code is required please Send the code", step = '1')
    cursor.execute("""
        SELECT timestamp FROM sms_table WHERE email = ?
    """, (email,))
    row = cursor.fetchone()
    expire = datetime.strptime(row[0], "%Y-%m-%d %H:%M:%S")

    if datetime.now() - expire > timedelta(minutes=5):
        cursor.execute("DELETE FROM sms_table WHERE email = ?", (email,))
        sql.commit()
        return render_template("/forgot_password.html", data="OTP expired Please resend the OTP")

    if sms != sms_record[0]:
        return render_template("/forgot_password.html", data="Invalid SMS code", step="2", email = email, type = type)

    if type == 'admin':
        cursor.execute("UPDATE admin_table SET password = ? WHERE email = ?", (new_password, email,))
    else:
        cursor.execute("UPDATE employee SET password = ? WHERE email = ?", (new_password, email,))
    cursor.execute("DELETE FROM sms_table WHERE email = ?", (email,))
    sql.commit()
    return render_template("/forgot_password.html", data="Password Updated Successfully")


@app.route("/send_forgot_sms", methods=["POST"])
def send_forgot_sms():
    email = request.form["email"]
    type = request.form["type"]
    
    if type == "admin":
        cursor.execute("SELECT email FROM admin_table WHERE email = ?", (email,))
    else:
        cursor.execute("SELECT email FROM employee WHERE email = ?", (email,))

    if cursor.fetchone() is None:
        return render_template('/forgot_password.html', data = 'Email Not Register')
    
    sms_code = random.randint(100000, 999999)
    cursor.execute("""INSERT OR REPLACE INTO sms_table (email, sms, timestamp)
                   VALUES (?, ?, ?)""",
                   (email, sms_code, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    sql.commit()
    if type == 'admin':
        send_email_admin(
            f"No Reply - Password Reset SMS Code",
            f"""Please Don't reply to this email, this is an autogenerated email.
            
                Gmail: {email} 
                Your password reset SMS code is: {sms_code}
                If you did not request a password reset, please ignore this email.
                
                Regards,
                Automated Leave Management System""")
    else:
        send_email_emp(
            f"No Reply - Password Reset SMS Code",
            f"""Please Don't reply to this email, this is an autogenerated email.
            
                Gmail: {email} 
                Your password reset SMS code is: {sms_code}
                If you did not request a password reset, please ignore this email.
                
                Regards,
                Automated Leave Management System""", email)
    return redirect(f"/forgot_password_page?email={email}&type={type}&step=2")


@app.route("/add_employee", methods=["POST"])
def insert_employee_data():
    email = request.form["email"].lower()
    name = request.form["name"]
    surname = request.form["surname"]
    department = request.form["department"]
    password = request.form["pass"]
    admin = request.form["admin"]
    join_date = request.form["join_date"]
    data = outer_add_emp(email,name, surname,department,password,admin,join_date)
    return render_template("add_employee.html", data = data)


@app.route("/applyleave", methods=["POST"])
def applyleave():
    email = session.get("email")
    name = session.get("user_name")
    surname = session.get("surname")
    apply_start_date = request.form["leave_start"]
    apply_end_date = request.form["leave_end"]
    leave_type = request.form["leave_type"]

    cursor.execute(f"SELECT {leave_type} FROM leave_remaining WHERE email = ?", (email,))
    remain = cursor.fetchone()

    if remain[0] <= 0:
        return render_template("apply_leave.html", data = f"{leave_type} leave stack is empty — cannot apply!")
        
    cursor.execute("""
            SELECT approve FROM approve_table
            WHERE email = ? AND leave_date_start = ?
    """, (email, apply_start_date))
    data = cursor.fetchall()
    for row in data:
        if row[0] == 'Pending' or row[0] == 'Approved':
            return render_template("apply_leave.html", data = f"You have already applied for leave on this date {apply_start_date}.")

    date_count(email, apply_start_date, apply_end_date, leave_type)
    cursor.execute("""
            INSERT INTO approve_table (email, leave_type, leave_date_start, leave_date_end, applyed_on)
            VALUES (?, ?, ?, ?, ?)
        """, (email, leave_type, apply_start_date, apply_end_date, datetime.now().date()))
    send_email_admin(
        f"No Reply - Leave Application Notification from {email}",
        f"""Please Don't reply to this email, this is an autogenerated email.
        
            Employee Name: {name} {surname} 
            Gmail: {email}
            Has applied for {leave_type} from {apply_start_date} to {apply_end_date}.
            Please review and take necessary action.
            Thank you.
            
            Regards,
            Automated Leave Management System""")
    
    send_email_emp(
        f"No Reply - Leave Application Submission Confirmation",
        f"""Please Don't reply to this email, this is an autogenerated email.
        
            Employee Name: {name} {surname}
            Gmail: {email} 
            Your leave application for {leave_type} from {apply_start_date} to {apply_end_date} has been submitted for approval.
            You will be notified once a decision has been made.
            Thank you.
            
            Regards,
            Automated Leave Management System""", email)
    sql.commit()
    return render_template("apply_leave.html", data = "Leave application sent for approval")


@app.route("/approve/<email>/<start>/<end>/<leave_type>/<dateon>", methods=["POST"])
def approve(email, start, end, leave_type, dateon):
    name = session.get("user_name")
    surname = session.get("surname")
    cursor.execute("""
        UPDATE approve_table
        SET approve = 'Approved'
        WHERE email = ? AND leave_date_start = ? AND leave_date_end = ? AND leave_type = ? AND applyed_on = ?
    """, (email, start, end, leave_type, dateon))

    cursor.execute("""
        INSERT INTO leave_record (email, leave_date_start, leave_date_end, leave_type, applyed_on)
        VALUES (?, ?, ?, ?, ?)
    """, (email, start, end, leave_type, dateon))
    send_email_emp(
        f"No Reply - Leave Application Approved Notification",
        f"""Please Don't reply to this email, this is an autogenerated email.
        
            Employee Name: {name} {surname}
            Gmail: {email} 
            Your leave application for {leave_type} from {start} to {end} has been approved.
            Thank you.
            
            Regards,
            Automated Leave Management System""", email)
    sql.commit()
    return redirect("/approve_leave_page")


@app.route("/reject/<email>/<start>/<end>/<leave_type>", methods=["POST"])
def reject(email, start, end, leave_type):
    name = session.get("user_name")
    surname = session.get("surname")
    cursor.execute("""
        UPDATE approve_table
        SET approve = 'Rejected'
        WHERE email = ? AND leave_date_start = ? AND leave_date_end = ? AND leave_type = ?
    """, (email, start, end, leave_type))
    
    start_date = datetime.strptime(start, "%Y-%m-%d")
    end_date = datetime.strptime(end, "%Y-%m-%d")
    days = (end_date - start_date).days + 1

    cursor.execute(f"""
        UPDATE leave_remaining
        SET {leave_type} = {leave_type} + ?
        WHERE email = ?
    """, (days, email))
    send_email_emp(
        f"No Reply - Leave Application Rejected Notification",
        f"""Please Don't reply to this email, this is an autogenerated email.
            
            Employee Name: {name} {surname}
            Gmail: {email} 
            Your leave application for {leave_type} from {start} to {end} has been rejected.
            Please contact your administrator for more details.
            Thank you.
            
            Regards,
            Automated Leave Management System""", email)
    sql.commit()
    return redirect("/approve_leave_page")


@app.route("/cancel/<email>/<start>/<end>/<leave_type>", methods=["POST"])
def cancel_action(email, start, end, leave_type):
    start_date = datetime.strptime(start, "%Y-%m-%d")
    end_date = datetime.strptime(end, "%Y-%m-%d")
    days = (end_date - start_date).days + 1

    cursor.execute(f"""
        UPDATE leave_remaining
        SET {leave_type} = {leave_type} + ?
        WHERE email = ?
    """, (days, email))

    cursor.execute("""
        DELETE FROM leave_record
        WHERE email = ? AND leave_date_start = ? AND leave_date_end = ? AND leave_type = ?
    """, (email, start, end, leave_type))

    cursor.execute("""
        DELETE FROM approve_table
        WHERE email = ? AND leave_date_start = ? AND leave_date_end = ? AND leave_type = ?
    """, (email, start, end, leave_type))

    sql.commit()
    return redirect("/leavehistory_page")


@app.route("/add_leave_balance", methods=["POST"])
def add_leave_balance():
    email = request.form["email"]
    leave_type = request.form["leave_type"]
    days = int(request.form["days"])
    if days < 0 :
        days = 0
    cursor.execute(f"""
        UPDATE leave_remaining
        SET {leave_type} = {leave_type} + ?
        WHERE email = ?
    """, (days, email))
    sql.commit()
    return render_template("add_leave_balance.html", data = f"Successfully added {days} {leave_type} days to {email}")


@app.route("/download_all_reports")
def download_all_reports():
    output = StringIO()
    if session.get("type") == 'admin':
        employees = cursor.execute("SELECT email, name, surname, department, join_date FROM employee").fetchall()

    if not employees:
        return "No employees found"

    for emp in employees:
        email, name, surname, department, join_date = emp

        output.write("\n=============================\n")
        output.write(f"EMPLOYEE: {email} - {name} {surname}\n")
        output.write("=============================\n\n")

        cursor.execute("""
            SELECT SL, CL, COFF, SV
            FROM leave_remaining
            WHERE email = ?
        """, (email,))
        remain = cursor.fetchone()

        df_remain = pd.DataFrame([{
            "Email": email,
            "Name": name,
            "Surname": surname,
            "Department": department,
            "Join Date": join_date,
            "SL Remaining": remain[0],
            "CL Remaining": remain[1],
            "COFF Remaining": remain[2],
            "SV Remaining": remain[3],
        }])

        output.write("=== Leave Remaining ===\n")
        df_remain.to_csv(output, index=False)
        output.write("\n")

        cursor.execute("""
            SELECT leave_type, leave_date_start, leave_date_end, approve
            FROM approve_table
            WHERE email = ?
            ORDER BY leave_date_start DESC
        """, (email,))
        history = cursor.fetchall()

        if not history:
            output.write("No leave records found.\n")
            continue
        
        df_hist = pd.DataFrame(history, columns=[
            "Leave Type", "Start Date", "End Date", "Status"
        ])

        df_hist["Month"] = pd.to_datetime(df_hist["Start Date"]).dt.strftime("%B %Y")

        for month, df_month in df_hist.groupby("Month"):
            output.write(f"=== Leave History — {month} ===\n")
            df_month.drop(columns=["Month"]).to_csv(output, index=False)
            output.write("\n")

    csv_text = output.getvalue()

    return Response(
        csv_text,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=All_Employee_Monthly_Report.csv"}
    )


@app.route("/logout")
def logout():
    email = session.get("email")
    session.clear()
    return redirect("/")

@app.before_request
def auto_logout():
    allowed_routes = [
        'home',
        'login_page',
        'admin_login_page',
        'login',
        'admin_login',

        'forgot_password_page',
        'forgot_password',
        'send_forgot_sms'
    ]

    if request.endpoint in allowed_routes:
        return

    if "email" not in session:
        session.clear()
        return redirect("/")

    now = time.time()
    last = session.get("last_activity")
    timeout = 300

    if last and (now - last > timeout):
        session.clear()
        return redirect("/")

    session["last_activity"] = now



if __name__ == "__main__":
    app.run(debug=True)


def update_leave(self, email, leave_type, data): #
  cursor.execute(f"UPDATE leave_remaining SET {leave_type} = ? WHERE email = ?", (data, email))
  sql.commit()
  return True


def sub_leave(self, email, leave_type):
  cursor.execute(f"UPDATE leave_remaining SET {leave_type} = {leave_type} - 1 WHERE email = ?", (email,))
  sql.commit()
  return True

